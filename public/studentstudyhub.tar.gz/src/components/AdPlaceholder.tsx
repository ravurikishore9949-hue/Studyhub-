import React from 'react';

interface AdPlaceholderProps {
  slotType?: 'banner' | 'rectangle' | 'sidebar';
  className?: string;
}

export const AdPlaceholder: React.FC<AdPlaceholderProps> = ({
  slotType = 'banner',
  className = ''
}) => {
  return (
    <div
      className={`my-6 overflow-hidden rounded-xl border border-dashed border-slate-300 dark:border-slate-800 bg-slate-100/60 dark:bg-slate-900/40 p-3 text-center transition-colors ${className}`}
      role="complementary"
      aria-label="Advertisement placeholder area"
    >
      <div className="flex flex-col items-center justify-center min-h-[90px] py-2">
        <span className="text-[10px] font-semibold tracking-wider uppercase text-slate-600 dark:text-slate-300">
          Advertisement Placeholder
        </span>
        <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 max-w-md">
          {slotType === 'banner' && 'Reserved standard responsive banner (728×90 / 320×50). Non-intrusive sponsor code can be embedded here.'}
          {slotType === 'rectangle' && 'Reserved medium rectangle ad area (300×250). Dedicated slot for relevant educational tools or book sponsors.'}
          {slotType === 'sidebar' && 'Reserved sidebar ad unit (160×600 / 300×600). Designed for clean separation without obstructing study reading.'}
        </p>
      </div>
    </div>
  );
};
